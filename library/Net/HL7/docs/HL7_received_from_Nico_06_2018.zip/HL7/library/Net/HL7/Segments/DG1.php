<?php

/**
 * DG1 (Diagnosis) segment class
 *
 */
class Net_HL7_Segments_DG1 extends Net_HL7_Segment {

    /**
     * Create an instance of the DG1 segment. 
     *
     * If an array argument is provided, all fields will be filled
     * from that array. Note that for composed fields and
     * subcomponents, the array may hold subarrays and
     * subsubarrays. 
     */
    function __construct($fields = NULL)
    {
        parent::__construct("DG1", $fields);
        
        if (!isset($fields)) {
			//set set-ID
			$this->setField(1, "1");
			$this->setField(6, "A");//Diagnosis-Type
		}
    }

	//Setter for most required fields
	
	/**
	 * @param number 1 or 2
	 */
	function setSetId($number)
	{
		return $this->setField(1, $number);
	}
	
	function setDiagnosisCode($code, $text, $scheme)
	{
		return $this->setField(3, array ($code, $text, $scheme));
	}
	

	
    
    
    //getter for most interesting fields
    function getSetId()
    {
		return $this->getField(1);
	}
	
    function getDiagnosisCode()
    {	
		$field = $this->getField(3);
		$names = array('code', 'text', 'scheme');
		$out = parent::nameSubsegements($field, $names);
		return $out;
	}	
	
	function getDiagnosisPriority()
    {	
		//1=Hauptdiagnose
		return $this->getField(15);
	}	
	

	function getDiagnosisType()
    {	
		//A=Admission, F=Discharge
		return $this->getField(6);
	}	
}

?>
