<?php

/**
 * PV1 (Patient visit) segment class
 *
 */
class Net_HL7_Segments_PV1 extends Net_HL7_Segment {

    /**
     * Create an instance of the PV1 segment. 
     *
     * If an array argument is provided, all fields will be filled
     * from that array. Note that for composed fields and
     * subcomponents, the array may hold subarrays and
     * subsubarrays. 
     */
    function __construct($fields = NULL)
    {
        parent::__construct("PV1", $fields);
        
        if (!isset($fields)) {
			$this->setAdmissionType("R");
		}
        
    }

	//Setter for most required fields
	
	/**
	 * I  = stationär
     * O = ambulant
	 * T = teilstationär
	 * @param code "I"|"O"|"T"
	 */
	function setPatientClass($code)
	{
		return $this->setField(2, $code);
	}
	
	function setAssignedPatientLocation($org1, $room, $bed, $org2)
	{
		return $this->setField(3, array($org1, $room, $bed, $org2));
	}	

	/**
	 * L = Entbindung, R = Normalaufnahme ==> always R
	 */
	function setAdmissionType($code="R")
	{
		return $this->setField(4, $code);
	}		
	
	function setPriorPatientLocation($pointOfCare, $room, $bed)
	{
		return $this->setField(6, array($pointOfCare, $room, $bed));
	}
	
	function setAttendingDoctor($id, $lastname, $firstname, $degree="" ,$prefix="", $suffix="" )
	{
		return $this->setField(7, array($id, $lastname, $firstname, $suffix, $prefix, $degree));
	}	
    
	function setReferringDoctor($id, $lastname, $firstname, $zip, $city, $street, $phone, $fax, $formOfAddress, $country="D", $degree="" ,$prefix="", $suffix="" )
	{
		return $this->setField(8, array($id, $lastname, $firstname, $suffix, $prefix, "", $degree, $country, array($zip, $city), $street, $phone, $fax, "", $formOfAddress));
	}	
	
 	function setConsultingDoctor($id, $lastname, $firstname, $zip, $city, $street, $phone, $fax, $formOfAddress, $country="D", $degree="" ,$prefix="", $suffix="" )
	{
		return $this->setField(9, array($id, $lastname, $firstname, $suffix, $prefix, "", $degree, $country, array($zip, $city), $street, $phone, $fax, "", $formOfAddress));
	}   
	
 	function setAdmitsource($id)
	{
		return $this->setField(14, $id);
	} 
	
  	function setVisitNumber($id, $check, $scheme="M11")
	{
		return $this->setField(19, array($id, $check, $scheme));
	}    
	
	function setChargePriceIndicator($code)
	{
		return $this->setField(21, $code);
	}  
	
	function setContractCode($code)
	{
		return $this->setField(24, $code);
	}  
	
	function setAdmitDate($timecode)
	{
		return $this->setField(44, $timecode);
	}  
	
	function setTotalPayments($count)
	{
		return $this->setField(49, $count);
	}  
	
	function setAlternateVisitID($id)
	{
		return $this->setField(50, $id);
	}  
	
	function setVisitIndicator($code)
	{
		return $this->setField(51, $code);
	}  	
	
    //getter for most interesting fields
    function getPatientClass()
    {
		return $this->getField(2);
	}
	
	function getAssignedPatientLocation()
	{
		$field = $this->getField(3);
		$names = array('org1', 'room', 'bed', 'org2');
		$out = parent::nameSubsegements($field, $names);
		//return (object) array('a'=>1,'b'=>2);
		return $out;
	}
		
	function getAdmissionType()
	{
		return $this->getField(4);
	}		
	
	function getPriorPatientLocation()
	{
		$field = $this->getField(6);
		$names = array('pointOfCare', 'room', 'bed');
		$out = parent::nameSubsegements($field, $names);
		return $out;
	}
	
	function getAttendingDoctor()
	{
		$field = $this->getField(7);
		$names = array('id', 'lastname', 'firstname','middlename', 'suffix', 'prefix', 'degree');
		$out = parent::nameSubsegements($field, $names);
		return $out;
	}
		
	function getReferringDoctor()
	{	
		$field = $this->getField(8);
		$names = array('id', 'lastname', 'firstname','middlename', 'suffix', 'prefix', 'degree', 'country', 'zipcity', 'street', 'phone', 'fax', 'formkey', 'formOfAddress');
		$out = parent::nameSubsegements($field, $names);
		return $out;
	}	
	
	function getConsultingDoctor()
	{
		$field = $this->getField(9);
		$names = array('id', 'lastname', 'firstname', 'middlename', 'suffix', 'prefix', 'degree', 'country', 'zipcity', 'street', 'phone', 'fax', 'formkey', 'formOfAddress');
		$out = parent::nameSubsegements($field, $names);
		return $out;
	}	
	
	function getAdmitSource()
	{
		return $this->getField(14);
	}
        
        function getAmbulantorystatus()
	{
		return $this->getField(15);
	}
	
	function getVisitNumber()
	{	
		$field = $this->getField(19);             
		$names = array('id', 'check', 'method');
                if (sizeof($field)==3){
                    $out = parent::nameSubsegements($field, $names);
                    } else{
                    $out = parent::nameSubsegements(array($field,), $names);   
                    }
		return $out;
	}  
	
	//P=Privatpatient, K=Krankenkasse
	function getChargePriceIndicator()
	{
		return $this->getField(21);
	}  
	
	function getContractCode()
	{
		return $this->getField(24);
	}  
	
	function getAdmitDate()	
	{
		return parent::convertDate($this->getField(44));
	}  
	
	function getDischargeLocation()	
	{
		return $this->getField(37);
	}  
	
	//YYYYMMDDhhmmss
	function getDischargeDate()	
	{
		return parent::convertDate($this->getField(45));
	}  
	
	function getTotalPayments()
	{
		return $this->getField(49);
	}  
	
	function getAlternateVisitID()
	{
		return $this->getField(50);
	}  
	
	function getVisitIndicator()
	{
		return $this->getField(51);
	}  
	
}

?>
