<?php

class Pms_Simplehl7sender {
var $_HANDLE;
var $_MESSAGE_PREFIX;
var $_MESSAGE_SUFFIX;
var $_MAX_READ;


/**
* Connect to specified host and port
*
* @param mixed Host to connect to
* @param int Port to connect to
*/
function _connect($host, $port)
{

$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
if ($socket < 0) {
trigger_error("create failed: " . socket_strerror($socket), E_USER_ERROR);
}

$result = socket_connect($socket, $host, $port);

if ($result < 0) {
trigger_error("connect failed: " . socket_strerror($result), E_USER_ERROR);
}

$this->_HANDLE= $socket;

$this->_MESSAGE_PREFIX = "\013";
$this->_MESSAGE_SUFFIX = "\034\015";
$this->_MAX_READ       = 8192;
$this->_TIMEOUT_SECS       = 10;

return true;
}


/**
* Sends a Net_HL7_Message object over this connection.
*/
function send($hl7Msg)
{
$handle = $this->_HANDLE;

socket_write($handle, $this->_MESSAGE_PREFIX . $hl7Msg . $this->_MESSAGE_SUFFIX);

$data = "";

//set Timeout
$timeout = array('sec'=>$this->_TIMEOUT_SECS,'usec'=>500000);
socket_set_option ( $handle , SOL_SOCKET , SO_RCVTIMEO, $timeout);

while(($buf = socket_read($handle, 256, PHP_BINARY_READ)) !== false) {
$data .= $buf;

if(preg_match("/" . $this->_MESSAGE_SUFFIX . "$/", $buf))
break;
}

// Remove message prefix and suffix
$data = preg_replace("/^" . $this->_MESSAGE_PREFIX . "/", "", $data);
$data = preg_replace("/" . $this->_MESSAGE_SUFFIX . "$/", "", $data);

//$resp = new Net_HL7_Message($data);

return $data;
}

/**
* Sends a Net_HL7_Message object over this connection.
*
* @param object Instance of Net_HL7_Message
* @return nothing!!
* @access public
* @see Net_HL7_Message
*/
function justSend($req)
{
$handle = $this->_HANDLE;
$hl7Msg = $req;

//$hl7Msg = $req->toString();
//$hl7Msg = trim($hl7Msg);
socket_write($handle, $this->_MESSAGE_PREFIX . $hl7Msg . $this->_MESSAGE_SUFFIX);

return;
}

/**
* Close the connection.
*
* @access public
* @return boolean
*/
function close()
{
socket_close($this->_HANDLE);
return true;
}


function sendMessage($msg_as_string, $host, $port)
{
    $send_real=true;//dbg-switch
    if($send_real) {
        $conn=$this->connect($host, $port);

        if (!$conn) {
            $this->log("Unable to connect to " . $host . ":" . $port, 2);
            return "FAIL, host:" . $host . ", port: " . $port;
        }

        $resp = $this->send($msg_as_string);
        $conn->close();
    }else{
        $resp="xxACK";
    }
    $this->log( "Sent \n" . $msg_as_string, 0);
    $returnvalue="FAIL";

    if (isset($resp) && strpos ( $resp , 'ACK' )>0){
        //$this->log( "Received answer \n" . $resp, 0);
        $returnvalue="OK";
    } else {
        //$this->log( "No ACK received \n" ,2);
        //if(isset($resp)) $this->log( $resp ,2);
        $returnvalue="No ACK received";
    }

    return  $returnvalue;
}


    function send_ft_for_essen($data, $host, $port){
        $msh="MSH|^~\&|ISPC|SIEMENS|EXTERNAL|FINANCIAL|%DATE1%||DFT^P03|2018051510191469585||2.3|";
        $evn="EVN|P03|%DATE1%|";
        $pid="PID|1||%PAT_EPID%^0^0||%PAT_LASTNAME%^%PAT_FISTNAME%^^^||%PAT_BIRTH%|%PAT_SEX%||||||||||%PAT_CASENO%|";
        $pv1="PV1|1||%AOE_P%|||||%AOE_F%|||||||||||%PAT_CASENO%|";
        $ft1="FT1|1|||%SUBJ_DATE2%|%SUBJ_DATE1%||%SUBJ_CODE%|||%SUBJ_SUM%||||||||||%AOE_P%^%AOE_F%|%AOE_P%^%AOE_F%|";



        $msg = implode("\n", array($msh,$evn,$pid,$pv1,$ft1));

        $vars=array(
            'DATE1'         =>  date("YmdHis"),
            'PAT_EPID'      =>  $data['epid'],
            'PAT_LASTNAME'  =>  $data['lastname'],
            'PAT_FISTNAME'  =>  $data['firstname'],
            'PAT_BIRTH'     =>  $data['birth'],         // 19541026
            'PAT_SEX'       =>  $data['sex'],           // M | F
            'PAT_CASENO'    =>  $data['caseno'],
            'AOE_P'         =>  "PMA9",
            'AOE_F'         =>  "PMA9",
            'EOE_P'         =>  "PMA9",
            'EOE_F'         =>  "PMA9",
            'SUBJ_CODE'     =>  "MPMA9VV",
            'SUBJ_SUM'      =>  $data['sum'],
            'SUBJ_DATE1'    =>  $data['date'],
            'SUBJ_DATE2'    =>  date('Ymd')
        );

        foreach($vars as $vk=>$vv){
            $msg = str_replace("%" . $vk ."%" , $vv, $msg);
        }

        $this->sendMessage($msg, $host, $port);

    }
}