ISPC HL7-Features

/socketserver_essen
In this directory is the socketserver
config.php: you have to change it to yout needs: clientid, userid of the server-user, ...
serve.php: is similar to ispcs index.html to get the bootstrap etc. done
serve_adt.sh: call this file to start the server. the server opens a socket and waits for connection.
The received messages are placed in the folder "messages". Then serve.php is called with that message as input.

/library/Net/HL7
This is the semi-crappy php-hl7-lib

Most logic is in /library/Net/SocketServerEssen.php. This parses the hl7-message and creates patients etc. 
You will most likely have to change or add some code so that it really can fill your db-columns.

/library/pms/Simplehl7sender::send_ft_for_essen()
This is a simple method for sending hl7-messages. It works with search&replace on a template-string.