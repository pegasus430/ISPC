<?php
abstract class BaseHl7Log extends Doctrine_Record
{

	function setTableDefinition ()
	{
		$this->setTableName('hl7_log');
		$this->hasColumn('id', 'bigint', NULL, array('type' => 'bigint', 'length' => NULL, 'primary' => true, 'autoincrement' => true));
		$this->hasColumn('date', 'datetime', NULL, array('type' => 'datetime', 'length' => NULL));
		$this->hasColumn('message', 'message', NULL, array('type' => 'text', 'length' => NULL));
		$this->hasColumn('level', 'int', 255, array('type' => 'int', 'length' => 255));
	}

	function setUp ()
	{
		//$this->actAs(new Createtimestamp());
	}

}
?>
